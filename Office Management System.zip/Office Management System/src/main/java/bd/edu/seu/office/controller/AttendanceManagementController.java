package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AttendanceManagement;
import bd.edu.seu.office.model.TaskManagement;
import bd.edu.seu.office.service.AttendanceManagementService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class AttendanceManagementController implements Initializable {

    @FXML
    private TableColumn<AttendanceManagement, String> amAttendanceColumn;

    @FXML
    private TableColumn<AttendanceManagement, String> amDateColumn;

    @FXML
    private DatePicker amDateField;

    @FXML
    private ChoiceBox<String> amMarkAttendanceChoiceBox;

    @FXML
    private TableColumn<AttendanceManagement, String> amNameColumn;

    @FXML
    private ChoiceBox<String> amNameChoiceBox;

    @FXML
    private TextField amSearchField;

    @FXML
    private TableView<AttendanceManagement> amTableView;

    private static AttendanceManagement oldAttendance;

    private static ObservableList<AttendanceManagement> attendanceObservableList = FXCollections.observableArrayList();

    @FXML
    void saveEvent(ActionEvent event) {
        String name = amNameChoiceBox.getValue();
        String date = amDateField.getValue().toString();
        String mark = amMarkAttendanceChoiceBox.getValue().toString();

        AttendanceManagement attendanceManagement = new AttendanceManagement(name, date, mark);
        AttendanceManagementService attendanceManagementService = new AttendanceManagementService();
        attendanceManagementService.insert(attendanceManagement);
        defaultTableView();
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String search = amSearchField.getText();
        AttendanceManagementService attendanceManagementService = new AttendanceManagementService();
        attendanceObservableList.setAll(attendanceManagementService.getSearchList(search.trim().toLowerCase()));
    }

    @FXML
    void updateEvent(ActionEvent event) {
        AttendanceManagement updatedAttendance = new AttendanceManagement(oldAttendance.getName(), oldAttendance.getDate(), amMarkAttendanceChoiceBox.getValue().toString());
        AttendanceManagementService attendanceManagementService = new AttendanceManagementService();
        attendanceManagementService.update(oldAttendance, updatedAttendance);
        defaultTableView();
        System.out.println("Update button clicked");
    }

    @FXML
    void deleteEvent(ActionEvent event) {
        AttendanceManagementService attendanceManagementService = new AttendanceManagementService();
        attendanceManagementService.delete(oldAttendance);
        defaultTableView();
    }

    @FXML
    void selectedRow(MouseEvent event) {
        AttendanceManagement attendanceManagement = amTableView.getSelectionModel().getSelectedItem();
        if (attendanceManagement == null) {
            System.out.println("No row selected");
            return;
        }
        showData(attendanceManagement);
    }

    @FXML
    void clearEvent(ActionEvent event) {
        amNameChoiceBox.setValue(null);
        amDateField.setValue(null);
        amMarkAttendanceChoiceBox.setValue(null);

        amTableView.getSelectionModel().clearSelection();
        oldAttendance = null;
    }

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

//        new AttendanceManagementService().insertDailyDefaultAttendanceIfNotExists();

        List<String> employeeEmails = AttendanceManagementService.getAllEmployeeEmails();
        amNameChoiceBox.getItems().addAll(employeeEmails);


        tableMapping();
        defaultTableView();


        ObservableList<String> statusList = FXCollections.observableArrayList();
        statusList.add("Present");
        statusList.add("Absent");
        statusList.add("Sick");
        amMarkAttendanceChoiceBox.setItems(statusList);

        AttendanceManagementService service = new AttendanceManagementService();
        service.markAbsentForAllIfNotExists(); // Call this to auto-fill "Absent"


    }



    private void tableMapping(){
        amNameColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getName()));
        amDateColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getDate()));
        amAttendanceColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getAttendance()));
        amTableView.setItems(attendanceObservableList);
    }

    public void defaultTableView(){
        AttendanceManagementService attendanceManagementService = new AttendanceManagementService();
        attendanceObservableList.setAll(attendanceManagementService.getList());
    }

    private void showData(AttendanceManagement attendance){
        oldAttendance = attendance;

        amNameChoiceBox.setValue(attendance.getName());
        amDateField.setValue(LocalDate.parse(attendance.getDate()));
        amMarkAttendanceChoiceBox.setValue(attendance.getAttendance());
    }
}
