package bd.edu.seu.office.model;

public class TaskManagement {
    private int number;
    private String name;
    private String deadline;
    private String description;

    public TaskManagement(int number, String name, String deadline, String description) {
        this.number = number;
        this.name = name;
        this.deadline = deadline;
        this.description = description;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
