package bd.edu.seu.office.dashboard;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.model.MyTask;
import bd.edu.seu.office.service.AssignTaskService;
import bd.edu.seu.office.util.Session;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class UserDashboardController implements Initializable {

    @FXML
    private AnchorPane mainUserAnchorPane;

    private void loadSubScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            AnchorPane pane = loader.load();
            mainUserAnchorPane.getChildren().setAll(pane);
        } catch (IOException ex) {
            System.err.println("Failed to load sub scene");
            ex.printStackTrace();
        }
    }

    @FXML
    void myAttendanceBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/mark_attendance.fxml");
    }

    @FXML
    void myContactBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/my_contact.fxml");
    }

    @FXML
    void myTaskBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/my_task.fxml");
    }

    @FXML
    void mySalaryEvent(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/my_salary.fxml");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadSubScene("/bd/edu/seu/office/mark_attendance.fxml");
        showDeadlineReminderAlert();
    }

    @FXML
    void logoutEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    private void showDeadlineReminderAlert() {
        List<MyTask> taskList = AssignTaskService.getTasksByEmail(Session.getCurrentUserEmail());
        LocalDate tomorrow = LocalDate.now().plusDays(1);

        StringBuilder reminderMessage = new StringBuilder();
        for (MyTask task : taskList) {
            LocalDate deadlineDate = LocalDate.parse(task.getDeadline());
            if (!task.getStatus().equalsIgnoreCase("Completed") && deadlineDate.equals(tomorrow)) {
                reminderMessage.append("Task: ").append(task.getTask())
                        .append(" | Deadline: ").append(task.getDeadline()).append("\n");
            }
        }

        if (!reminderMessage.toString().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Task Reminder");
            alert.setHeaderText("You have tasks due tomorrow!");
            alert.setContentText(reminderMessage.toString());
            alert.showAndWait();
        }
    }


}
