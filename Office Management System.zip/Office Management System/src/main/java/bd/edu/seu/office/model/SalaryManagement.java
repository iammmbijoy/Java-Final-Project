package bd.edu.seu.office.model;

public class SalaryManagement {

    private String employeeName;
    private String month;
    private double salary;

    public SalaryManagement(String employeeName, String month, double salary) {
        this.employeeName = employeeName;
        this.month = month;
        this.salary = salary;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
