package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.service.AddEmployeeService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ForgetPasswordController {

    @FXML
    private PasswordField confirmPasswordField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField newPasswordField;

    @FXML
    void backEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    void resetEvent(ActionEvent event) {
        String email = emailField.getText().trim();
        String newPass = newPasswordField.getText();
        String confirmPass = confirmPasswordField.getText();

        if (email.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
            showAlert("Error", "Please fill all fields.");
            return;
        }

        if (!newPass.equals(confirmPass)) {
            showAlert("Error", "Passwords do not match.");
            return;
        }

        AddEmployeeService service = new AddEmployeeService();

        // for check email exist or not
        if (!service.isEmailExists(email)) {
            showAlert("Error", "No account found with this email.");
            return;
        }

        // for update password
        service.updatePasswordByEmail(email, newPass);

        showAlert("Success", "Password reset successful!");
    }

    private void showAlert(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


}
