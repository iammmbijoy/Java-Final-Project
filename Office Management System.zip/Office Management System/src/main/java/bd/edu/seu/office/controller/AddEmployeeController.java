package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.service.AddEmployeeService;
import bd.edu.seu.office.util.Session;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddEmployeeController implements Initializable {

        @FXML
        private TableColumn<AddEmp, String> empDateColumn;

        @FXML
        private TableColumn<AddEmp, String> empEmailColumn;

        @FXML
        private TextField empEmailField;

        @FXML
        private TableColumn<AddEmp, String> empGenderColumn;

        @FXML
        private ToggleGroup empGenderGroup;

        @FXML
        private TableColumn<AddEmp, String> empNameColumn;

        @FXML
        private TextField empNameField;

        @FXML
        private TableColumn<AddEmp, String> empPasswordColumn;

        @FXML
        private PasswordField empPasswordField;

        @FXML
        private TableColumn<AddEmp, String> empPhoneColumn;

        @FXML
        private TextField empPhoneField;

        @FXML
        private DatePicker empDateField;

        @FXML
        private TextField employeeSearchField;

        @FXML
        private TableView<AddEmp> employeeTableView;

        @FXML
        private Button deleteButton;

        @FXML
        private Button saveButton;

        @FXML
        private Button updateButton;

        @FXML
        private Button exiButton;

        @FXML
        private Button clearButton;


        private static AddEmp oldEmployee;

        private static ObservableList<AddEmp> employeeObservableList = FXCollections.observableArrayList();

        @FXML
        void deleteEvent(ActionEvent event) {
                AddEmployeeService addEmployeeService = new AddEmployeeService();
                addEmployeeService.delete(oldEmployee);
                defaultTableView();
        }

        @FXML
        void clearEvent(ActionEvent event) {
                empNameField.clear();
                empEmailField.clear();
                empPhoneField.clear();
                empPasswordField.clear();
                empDateField.setValue(null);
                empGenderGroup.selectToggle(null); // Deselect radio buttons

                employeeTableView.getSelectionModel().clearSelection(); // Unselect row
                oldEmployee = null;
        }

        @FXML
        void saveEvent(ActionEvent event) {
                String name = empNameField.getText();
                String email = empEmailField.getText();
                String phone = empPhoneField.getText();
                String date = empDateField.getValue().toString();
                String password = empPasswordField.getText();
                RadioButton selectedGender = (RadioButton) empGenderGroup.getSelectedToggle();
                String gender = selectedGender.getText();

                if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || password.isEmpty() || gender.isEmpty()) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText(null);
                        alert.setContentText("Please fill all the fields");
                        alert.showAndWait();
                } else {
                        AddEmp table = new AddEmp(name, email, phone, password, date, gender);
                        AddEmployeeService addEmployeeService = new AddEmployeeService();
                        addEmployeeService.insert(table);
                        defaultTableView();
                }

        }
        @FXML
        void selectedRow(MouseEvent event) {
                AddEmp employee = employeeTableView.getSelectionModel().getSelectedItem();
                if (employee == null) {
                        System.out.println("No employee selected.");
                        return;
                }
                showData(employee);

        }

        @FXML
        void updateEvent(ActionEvent event) {
                AddEmp updateEmployee = new AddEmp(empNameField.getText(), oldEmployee.getEmail(), empPhoneField.getText(), empPasswordField.getText(), empDateField.getValue().toString(),
                        ((RadioButton) empGenderGroup.getSelectedToggle()).getText());
                AddEmployeeService addEmployeeService = new AddEmployeeService();
                addEmployeeService.update(oldEmployee, updateEmployee);
                defaultTableView();
                System.out.println("update button clicked");
        }

        @FXML
        void exitEvent(ActionEvent event) {
            HelloApplication.changeScene("login");
        }

        @FXML
        void searchEvent(KeyEvent event) {
                String search = employeeSearchField.getText();
                AddEmployeeService addEmployeeService = new AddEmployeeService();
                employeeObservableList.setAll(addEmployeeService.getSearchList(search.trim().toLowerCase()));
        }

        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {
                tableMapping();
                defaultTableView();

        }

        private void tableMapping(){
                empNameColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getName()));
                empEmailColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getEmail()));
                empPhoneColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getPhone()));
                empPasswordColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getPassword()));
                empGenderColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getGender()));
                empDateColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getDate()));
                employeeTableView.setItems(employeeObservableList);
        }

        public void defaultTableView(){
                AddEmployeeService addEmployeeService = new AddEmployeeService();
                employeeObservableList.setAll(addEmployeeService.getList());
        }

        private void showData(AddEmp employee) {

                oldEmployee = employee;
                empNameField.setText(employee.getName());
                empEmailField.setText(employee.getEmail());
                empPhoneField.setText(employee.getPhone());
                empPasswordField.setText(employee.getPassword());
                empDateField.setValue(LocalDate.parse(employee.getDate()));
                for (Toggle toggle : empGenderGroup.getToggles()) {
                        RadioButton rb = (RadioButton) toggle;
                        if (rb.getText().equalsIgnoreCase(employee.getGender())) {
                                empGenderGroup.selectToggle(rb);
                                break;
                        }
                }
        }
}

