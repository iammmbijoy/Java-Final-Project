package bd.edu.seu.office.user;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.service.AddEmployeeService;
import bd.edu.seu.office.util.Session;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField visiblePasswordField;

    @FXML
    private CheckBox showPasswordCheckBox;


    @FXML
    void goToAdmin(MouseEvent event) {
        HelloApplication.changeScene("admin");

    }

    @FXML
    void loginEvent(ActionEvent event) {
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();

        AddEmployeeService service = new AddEmployeeService();
        AddEmp user = service.loginCheck(email, password);

        if (user != null) {
            Session.setCurrentUserEmail(user.getEmail());
            HelloApplication.changeScene("user_dashboard"); // if login is successful
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText(null);
            alert.setContentText("Invalid email or password. Try again!");
            alert.showAndWait();
        }

    }

    @FXML
    void forgetPassword(MouseEvent event) {
        HelloApplication.changeScene("forget_password");
    }

    @FXML
    void togglePasswordVisibility(ActionEvent event) {
        if (showPasswordCheckBox.isSelected()) {
            visiblePasswordField.setText(passwordField.getText());
            visiblePasswordField.setVisible(true);
            visiblePasswordField.setManaged(true);
            passwordField.setVisible(false);
            passwordField.setManaged(false);
        } else {
            passwordField.setText(visiblePasswordField.getText());
            passwordField.setVisible(true);
            passwordField.setManaged(true);
            visiblePasswordField.setVisible(false);
            visiblePasswordField.setManaged(false);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        visiblePasswordField.textProperty().bindBidirectional(passwordField.textProperty());
    }
}

