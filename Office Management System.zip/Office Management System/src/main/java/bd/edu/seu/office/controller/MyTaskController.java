package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.MyTask;
import bd.edu.seu.office.service.AssignTaskService;
import bd.edu.seu.office.util.Session;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class MyTaskController implements Initializable {

    @FXML
    private ChoiceBox<String> atTaskStatusChoiceBox;

    @FXML
    private TableColumn<MyTask, String> deadlineColumn;

    @FXML
    private TableView<MyTask> mtTableView;

    @FXML
    private TextField searchField;

    @FXML
    private TableColumn<MyTask, String> statusColumn;

    @FXML
    private TableColumn<MyTask, String> taskNameColumn;

    private static ObservableList<MyTask> myTaskObservableList = FXCollections.observableArrayList();
    private AssignTaskService assignTaskService = new AssignTaskService();
    private MyTask selectedTask = null;

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String keyword = searchField.getText().toLowerCase();
        List<MyTask> filtered = myTaskObservableList.stream()
                .filter(task -> task.getTask().toLowerCase().contains(keyword))
                .collect(Collectors.toList());
        mtTableView.setItems(FXCollections.observableArrayList(filtered));
    }

    @FXML
    void selectedRow(MouseEvent event) {

        selectedTask = mtTableView.getSelectionModel().getSelectedItem();
        if (selectedTask != null) {
            String taskDeadline = selectedTask.getDeadline(); // "yyyy-MM-dd" format
            LocalDate deadlineDate = LocalDate.parse(taskDeadline);
            LocalDate today = LocalDate.now();

            ObservableList<String> statusOptions;

            if (today.isAfter(deadlineDate)) {
                // if deadline is over then don't show completed option
                statusOptions = FXCollections.observableArrayList("In Progress", "Pending");
            } else {
                // if deadline is not over than show all
                statusOptions = FXCollections.observableArrayList("Completed", "In Progress", "Pending");
            }

            atTaskStatusChoiceBox.setItems(statusOptions);
            atTaskStatusChoiceBox.setValue(selectedTask.getStatus());
        }
    }

    @FXML
    void updateEvent(ActionEvent event) {
        if (selectedTask != null) {
            String newStatus = atTaskStatusChoiceBox.getValue();
            assignTaskService.updateTaskStatus(Session.getCurrentUserEmail(), selectedTask.getTask(), newStatus);
            loadTasks();
        }
    }

    private void tableMapping() {
        taskNameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTask()));
        deadlineColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDeadline()));
        statusColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatus()));
        mtTableView.setItems(myTaskObservableList);


    }

    private void loadTasks() {
        List<MyTask> taskList = assignTaskService.getTasksByEmail(Session.getCurrentUserEmail());
        myTaskObservableList.setAll(taskList);
        mtTableView.setItems(myTaskObservableList);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<String> statusList = FXCollections.observableArrayList();
        statusList.add("Completed");
        statusList.add("In Progress");
        statusList.add("Pending");
        atTaskStatusChoiceBox.setItems(statusList);

        tableMapping();
        loadTasks();
    }
}