package bd.edu.seu.office.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionSingleton {
    private static final String DB_HOST = "localhost";
    private static final String DB_PORT = "3306";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "seucse613";
    private static final String DB_NAME = "OfficeManagementSystem";
    private static final String DB_URL = "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME;

    private static Connection connection;
    private static ConnectionSingleton instance = new ConnectionSingleton();

    public ConnectionSingleton(){

        try {
            connection= DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to connect to database");
        }
    }
    public static Connection getConnection(){
        return connection;
    }
}


// create database OfficeManagementSystem;
// use OfficeManagementSystem;
// create table add_employee(name varchar(50), email varchar(100) PRIMARY KEY, phone varchar(11), password varchar(50), date varchar(50), gender varchar(10));
// create table task_management(number int UNIQUE, name varchar(50), deadline varchar(50), description varchar(200));
// create table assign_task(name varchar(50), task varchar(50), deadline varchar(50), status varchar(50));
// create table attendance_management(name varchar(50), date varchar(50), attendance varchar(20));
// create table salary_management(name varchar(50), month varchar(20), salary double);



//mysql> use OfficeManagementSystem;
//Database changed
//mysql> show tables;
//+----------------------------------+
//        | Tables_in_officemanagementsystem |
//        +----------------------------------+
//        | add_employee                     |
//        | assign_task                      |
//        | attendance_management            |
//        | salary_management                |
//        | task_management                  |
//        +----------------------------------+
//        5 rows in set (0.221 sec)
//
//mysql> describe add_employee;
//+----------+--------------+------+-----+---------+-------+
//        | Field    | Type         | Null | Key | Default | Extra |
//        +----------+--------------+------+-----+---------+-------+
//        | name     | varchar(50)  | YES  |     | NULL    |       |
//        | email    | varchar(100) | NO   | PRI | NULL    |       |
//        | phone    | varchar(11)  | YES  |     | NULL    |       |
//        | password | varchar(50)  | YES  |     | NULL    |       |
//        | date     | varchar(50)  | YES  |     | NULL    |       |
//        | gender   | varchar(10)  | YES  |     | NULL    |       |
//        +----------+--------------+------+-----+---------+-------+
//        6 rows in set (0.203 sec)
//
//mysql> describe assign_task;
//+----------+-------------+------+-----+---------+-------+
//        | Field    | Type        | Null | Key | Default | Extra |
//        +----------+-------------+------+-----+---------+-------+
//        | name     | varchar(50) | YES  |     | NULL    |       |
//        | task     | varchar(50) | YES  |     | NULL    |       |
//        | deadline | varchar(50) | YES  |     | NULL    |       |
//        | status   | varchar(50) | YES  |     | NULL    |       |
//        +----------+-------------+------+-----+---------+-------+
//        4 rows in set (0.152 sec)
//
//mysql> describe attendance_management;
//+------------+-------------+------+-----+---------+-------+
//        | Field      | Type        | Null | Key | Default | Extra |
//        +------------+-------------+------+-----+---------+-------+
//        | name       | varchar(50) | YES  |     | NULL    |       |
//        | date       | varchar(50) | YES  |     | NULL    |       |
//        | attendance | varchar(20) | YES  |     | NULL    |       |
//        +------------+-------------+------+-----+---------+-------+
//        3 rows in set (0.015 sec)
//
//mysql> describe task_management;
//+-------------+--------------+------+-----+---------+-------+
//        | Field       | Type         | Null | Key | Default | Extra |
//        +-------------+--------------+------+-----+---------+-------+
//        | number      | int          | YES  | UNI | NULL    |       |
//        | name        | varchar(50)  | YES  |     | NULL    |       |
//        | deadline    | varchar(50)  | YES  |     | NULL    |       |
//        | description | varchar(200) | YES  |     | NULL    |       |
//        +-------------+--------------+------+-----+---------+-------+
//        4 rows in set (0.014 sec)
//
//mysql> describe salary_management;
//+--------+-------------+------+-----+---------+-------+
//        | Field  | Type        | Null | Key | Default | Extra |
//        +--------+-------------+------+-----+---------+-------+
//        | name   | varchar(50) | YES  |     | NULL    |       |
//        | month  | varchar(20) | YES  |     | NULL    |       |
//        | salary | double      | YES  |     | NULL    |       |
//        +--------+-------------+------+-----+---------+-------+
//        3 rows in set (0.015 sec)