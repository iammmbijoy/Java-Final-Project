package bd.edu.seu.office.model;

public class AttendanceManagement {
    private String name;
    private String date;
    private String Attendance;

    public AttendanceManagement(String name, String date, String attendance) {
        this.name = name;
        this.date = date;
        Attendance = attendance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAttendance() {
        return Attendance;
    }

    public void setAttendance(String attendance) {
        Attendance = attendance;
    }
}
