package bd.edu.seu.office.service;

import bd.edu.seu.office.interfaces.AssignTaskInterface;
import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.model.MyTask;
import bd.edu.seu.office.model.TaskManagement;
import bd.edu.seu.office.util.ConnectionSingleton;
import bd.edu.seu.office.util.Session;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AssignTaskService implements AssignTaskInterface {
    @Override
    public void insert(AssignTask table) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "insert into assign_task values(?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, table.getName());
            preparedStatement.setString(2, table.getTask());
            preparedStatement.setString(3, table.getDeadline());
            preparedStatement.setString(4, table.getStatus());
            preparedStatement.executeUpdate();
        } catch (SQLException ex){
            System.out.println("Failed to insert data into table");
            ex.printStackTrace();
        }
    }

    @Override
    public void update(AssignTask old, AssignTask update) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "update assign_task set name=?,task=?,deadline=?,status=? where name=? and task=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, update.getName());
            preparedStatement.setString(2, update.getTask());
            preparedStatement.setString(3, update.getDeadline());
            preparedStatement.setString(4, update.getStatus());
            preparedStatement.setString(5, old.getName());
            preparedStatement.setString(6, old.getTask());
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Failed to update data into table");
            ex.printStackTrace();

        }
    }

    @Override
    public void delete(AssignTask old) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "delete from assign_task where name=? and task=? and deadline=? and status=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, old.getName());
            preparedStatement.setString(2, old.getTask());
            preparedStatement.setString(3, old.getDeadline());
            preparedStatement.setString(4, old.getStatus());
            preparedStatement.executeUpdate();

        } catch (SQLException ex){
            System.out.println("Failed to delete data into table");
            ex.printStackTrace();
        }
    }

    @Override
    public List<AssignTask> getList() {
        List<AssignTask> list = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "select * from assign_task";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                AssignTask at = new AssignTask(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
                list.add(at);
            }
        }catch (SQLException ex) {
            System.out.println("Failed to get data from database");
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<AssignTask> getSearchList(String search) {
        return getList().stream().filter(at -> at.getName().toLowerCase().contains(search)
        || at.getTask().toLowerCase().contains(search)
    || at.getDeadline().toLowerCase().contains(search)).toList();
    }



    public static List<MyTask> getTasksByEmail(String email) {
        List<MyTask> list = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT task, deadline, status FROM assign_task WHERE name = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                MyTask mt = new MyTask(
                        resultSet.getString("task"),
                        resultSet.getString("deadline"),
                        resultSet.getString("status")
                );
                list.add(mt);
            }
        } catch (SQLException ex) {
            System.out.println("Failed to getTaskByEmail from database");
            ex.printStackTrace();
        }
        return list;
    }

    public void updateTaskStatus(String email, String taskName, String newStatus) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "UPDATE assign_task SET status = ? WHERE name = ? AND task = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, newStatus);
            statement.setString(2, email);
            statement.setString(3, taskName);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Failed to updateTaskStatus into table");
            e.printStackTrace();
        }
    }

    private List<MyTask> taskList = new ArrayList<>();

    public AssignTaskService() {
        // load tasklist from database
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT task, deadline, status FROM assign_task";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                MyTask mt = new MyTask(
                        resultSet.getString("task"),
                        resultSet.getString("deadline"),
                        resultSet.getString("status")
                );
                taskList.add(mt);
            }
        } catch (SQLException e) {
            System.out.println("Failed to getTasks from database");
            e.printStackTrace();
        }
    }

    public List<MyTask> getAllTasks() {
        return taskList;
    }
}
