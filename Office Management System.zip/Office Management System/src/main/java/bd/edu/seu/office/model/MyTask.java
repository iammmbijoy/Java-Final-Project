package bd.edu.seu.office.model;

public class MyTask {
    private String task;
    private String deadline;
    private String status;

    public MyTask(String task, String deadline, String status) {
        this.task = task;
        this.deadline = deadline;
        this.status = status;
    }

    public String getTask() {
        return task;
    }

    public String getDeadline() {
        return deadline;
    }

    public String getStatus() {
        return status;
    }
}

