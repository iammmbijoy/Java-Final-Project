package bd.edu.seu.office.service;

import bd.edu.seu.office.interfaces.AttendanceManagementInterface;
import bd.edu.seu.office.model.AttendanceManagement;
import bd.edu.seu.office.model.TaskManagement;
import bd.edu.seu.office.util.ConnectionSingleton;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static bd.edu.seu.office.util.ConnectionSingleton.getConnection;

public class AttendanceManagementService implements AttendanceManagementInterface {
    @Override
    public void insert(AttendanceManagement table) {
        try {
            Connection connection = getConnection();
            String query = "insert into attendance_management values(?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, table.getName());
            preparedStatement.setString(2, table.getDate().toString());
            preparedStatement.setString(3, table.getAttendance());
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Insert data into table attendance management failed");
            ex.printStackTrace();
        }
    }

    @Override
    public void update(AttendanceManagement old, AttendanceManagement update) {
        try {
            Connection connection = getConnection();
            String query = "update attendance_management set attendance=? where name=? and date=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
//            preparedStatement.setString(1, update.getDate());
            preparedStatement.setString(1, update.getAttendance());
            preparedStatement.setString(2, old.getName());
            preparedStatement.setString(3, old.getDate().toString());
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Update data into table attendance management failed");
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(AttendanceManagement old) {
        try {
            Connection connection = getConnection();
            String query = "delete from attendance_management where name=? and date=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, old.getName());
            preparedStatement.setString(2, old.getDate().toString());
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Delete data into table attendance management failed");
            ex.printStackTrace();
        }
    }

    @Override
    public List<AttendanceManagement> getList() {
        List<AttendanceManagement> list = new ArrayList<>();
        try {
            Connection connection = getConnection();
            String query = "select * from attendance_management";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                AttendanceManagement am = new AttendanceManagement(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3));
                list.add(am);
            }
        } catch (SQLException ex) {
            System.out.println("Failed to get attendance management data from database");
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<AttendanceManagement> getSearchList(String search) {
        return getList().stream().filter(am -> am.getName().toLowerCase().contains(search)
                || am.getDate().toLowerCase().contains(search) || am.getAttendance().toLowerCase().contains(search)).toList();
    }

    public static List<String> getAllEmployeeEmails() {
        List<String> emailList = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT email FROM add_employee";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                emailList.add(resultSet.getString("email"));
            }
        } catch (SQLException ex) {
            System.out.println("Failed to get all employee emails from database");
            ex.printStackTrace();
        }

        return emailList;
    }

//    public void insertDailyDefaultAttendanceIfNotExists() {
//        try {
//            Connection connection = getConnection();
//            String today = LocalDate.now().toString();
//
//            // Get all employee emails
//            List<String> allEmails = getAllEmployeeEmails();
//
//            for (String email : allEmails) {
//                String checkQuery = "SELECT * FROM attendance_management WHERE name=? AND date=?";
//                PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
//                checkStmt.setString(1, email);
//                checkStmt.setString(2, today);
//                ResultSet rs = checkStmt.executeQuery();
//
//                if (!rs.next()) {
//                    // If not exists, insert Absent
//                    String insertQuery = "INSERT INTO attendance_management(name, date, attendance) VALUES (?, ?, ?)";
//                    PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
//                    insertStmt.setString(1, email);
//                    insertStmt.setString(2, today);
//                    insertStmt.setString(3, "Absent");
//                    insertStmt.executeUpdate();
//                }
//            }
//        } catch (SQLException e) {
//            System.out.println("Error inserting default attendance.");
//            e.printStackTrace();
//        }
//    }

    public void markAbsentForAllIfNotExists() {
        Connection connection = ConnectionSingleton.getConnection();
        String today = LocalDate.now().toString();

        try {
            // Step 1: get all employees
            String empQuery = "SELECT email FROM add_employee";
            PreparedStatement empStmt = connection.prepareStatement(empQuery);
            ResultSet empResult = empStmt.executeQuery();

            while (empResult.next()) {
                String email = empResult.getString("email");

                // Step 2: check if attendance for today exists
                String checkQuery = "SELECT * FROM attendance_management WHERE name = ? AND date = ?";
                PreparedStatement checkStmt = connection.prepareStatement(checkQuery);
                checkStmt.setString(1, email);
                checkStmt.setString(2, today);
                ResultSet rs = checkStmt.executeQuery();

                if (!rs.next()) {
                    // Step 3: insert Absent record if not exists
                    String insertQuery = "INSERT INTO attendance_management (name, date, attendance) VALUES (?, ?, ?)";
                    PreparedStatement insertStmt = connection.prepareStatement(insertQuery);
                    insertStmt.setString(1, email);
                    insertStmt.setString(2, today);
                    insertStmt.setString(3, "Absent");
                    insertStmt.executeUpdate();
                }
            }
        } catch (Exception e) {
            System.out.println("Failed to connect markAbsentForAllIfNotExist");
            e.printStackTrace();
        }
    }
}