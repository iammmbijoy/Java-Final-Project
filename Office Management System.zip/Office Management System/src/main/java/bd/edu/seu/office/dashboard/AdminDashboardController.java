package bd.edu.seu.office.dashboard;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.service.AssignTaskService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ListView;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {

    @FXML
    private AnchorPane mainContentAnchorPane;

    // Reusable method to load subscenes
    private void loadSubScene(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            AnchorPane pane = loader.load();
            mainContentAnchorPane.getChildren().setAll(pane);
        } catch (IOException ex) {
            System.err.println("Failed to load sub scene");
            ex.printStackTrace();
        }
    }


    // Sidebar button action for Add Employee
    @FXML
    void addEmployeeBar(ActionEvent event) {
        // fxml path my scene
        loadSubScene("/bd/edu/seu/office/employee_dashboard.fxml");
    }

    @FXML
    void assignTaskBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/asignTask_dashboard.fxml");
    }

    @FXML
    void attendanceManagementBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/attendanceManagement_dashboard.fxml");

    }

    @FXML
    void salaryManagementBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/salaryManagement_dashboard.fxml");
    }

    @FXML
    void taskManagementBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/taskManagement_dashboard.fxml");
    }

    @FXML
    void reportManagementBar(ActionEvent event) {
        loadSubScene("/bd/edu/seu/office/reportManagement_dashboard.fxml");
    }


    @FXML
    void logoutEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    // This runs automatically when the scene loads
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Load employee dashboard by default
        loadSubScene("/bd/edu/seu/office/attendanceManagement_dashboard.fxml");
    }




}




