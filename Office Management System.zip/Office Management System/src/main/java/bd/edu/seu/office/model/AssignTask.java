package bd.edu.seu.office.model;

public class AssignTask {
    private String name;
    private String task;
    private String deadline;
    private String status;

    public AssignTask(String name, String task, String deadline, String status) {
        this.name = name;
        this.task = task;
        this.deadline = deadline;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public String getDeadline() {
        return deadline;
    }

    public void setDeadline(String deadline) {
        this.deadline = deadline;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
