package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.service.AddEmployeeService;
import bd.edu.seu.office.util.Session;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.net.URL;
import java.util.ResourceBundle;

public class MyContactController implements Initializable {

    @FXML
    private Label mcDateLabel;

    @FXML
    private Label mcEmailLabel;

    @FXML
    private Label mcGenderLabel;

    @FXML
    private Label mcNameLabel;

    @FXML
    private Label mcPasswordLabel;

    @FXML
    private Label mcPhoneLabel;

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // user email from session
        String loggedInEmail = Session.getCurrentUserEmail();
        System.out.println("[MyContactController] Logged in email: " + loggedInEmail);

        if (loggedInEmail != null && !loggedInEmail.isEmpty()) {
            AddEmployeeService service = new AddEmployeeService();

            AddEmp emp = service.getByEmail(loggedInEmail);

            if (emp != null) {
                System.out.println("[MyContactController] Employee found: " + emp.getName());
                mcNameLabel.setText(emp.getName());
                mcEmailLabel.setText(emp.getEmail());
                mcPhoneLabel.setText(emp.getPhone());
                mcPasswordLabel.setText(emp.getPassword());
                mcDateLabel.setText(emp.getDate());
                mcGenderLabel.setText(emp.getGender());
            } else {
                System.out.println("[MyContactController] No employee found with email: " + loggedInEmail);
            }
        } else {
            System.out.println("[MyContactController] No logged-in email found in Session.");
        }
    }
}

