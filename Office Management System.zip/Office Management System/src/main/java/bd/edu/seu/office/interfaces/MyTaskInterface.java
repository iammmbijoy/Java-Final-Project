package bd.edu.seu.office.interfaces;

import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.model.MyTask;

import java.util.List;

public interface MyTaskInterface {
    void update(MyTask old, MyTask update);
//    public List<MyTask> getList();
    List<MyTask> getSearchList(String search);
}
