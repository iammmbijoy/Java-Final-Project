package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.SalaryManagement;
import bd.edu.seu.office.service.SalaryManagementService;
import bd.edu.seu.office.util.Session;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class MySalaryController {

    @FXML
    private TextField amSearchField;

    @FXML
    private TableColumn<SalaryManagement, String> smMonthColumn;

    @FXML
    private TableColumn<SalaryManagement, Number> smSalaryColumn;

    @FXML
    private TableView<SalaryManagement> smTableView;

    private final ObservableList<SalaryManagement> mySalaryList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Table Mapping
        smMonthColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getMonth()));
        smSalaryColumn.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getSalary()));
        smTableView.setItems(mySalaryList);

        loadMySalary();
    }

    private void loadMySalary() {
        String currentEmail = Session.getCurrentUserEmail();
        SalaryManagementService salaryService = new SalaryManagementService();

        mySalaryList.setAll(
                salaryService.getList().stream()
                        .filter(s -> s.getEmployeeName().equals(currentEmail))
                        .toList()
        );
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String search = amSearchField.getText().trim().toLowerCase();
        String currentEmail = Session.getCurrentUserEmail();
        SalaryManagementService salaryService = new SalaryManagementService();

        mySalaryList.setAll(
                salaryService.getList().stream()
                        .filter(s -> s.getEmployeeName().equals(currentEmail)
                                && s.getMonth().toLowerCase().contains(search))
                        .toList()
        );
    }

    @FXML
    void selectedRow(MouseEvent event) {
        // Optional: show alert or log clicked data
        SalaryManagement selected = smTableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            System.out.println("Selected Salary Row: " + selected.getMonth() + ", " + selected.getSalary());
        }
    }

    @FXML
    void exitEvent(javafx.event.ActionEvent event) {
        HelloApplication.changeScene("login");
    }
}

