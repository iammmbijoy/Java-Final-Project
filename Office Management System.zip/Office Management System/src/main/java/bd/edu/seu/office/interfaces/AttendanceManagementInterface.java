package bd.edu.seu.office.interfaces;
import bd.edu.seu.office.model.AttendanceManagement;
import java.util.List;

public interface AttendanceManagementInterface {
    void insert(AttendanceManagement table);
    void update(AttendanceManagement old, AttendanceManagement update);
    void delete(AttendanceManagement old);
    List<AttendanceManagement> getList();
    List<AttendanceManagement> getSearchList(String search);
}
