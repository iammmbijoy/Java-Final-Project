package bd.edu.seu.office.interfaces;

import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.model.AssignTask;

import java.util.List;

public interface AssignTaskInterface {
    void insert(AssignTask table);
    void update(AssignTask old, AssignTask update);
    void delete(AssignTask old);
    List<AssignTask> getList();
    List<AssignTask> getSearchList(String search);
}
