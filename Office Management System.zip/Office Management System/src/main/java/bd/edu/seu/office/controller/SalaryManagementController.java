package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.model.SalaryManagement;
import bd.edu.seu.office.service.AttendanceManagementService;
import bd.edu.seu.office.service.SalaryManagementService;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class SalaryManagementController implements Initializable {

    @FXML
    private TextField searchField;

    @FXML
    private ChoiceBox<String> employeeNameChoiceBox;

    @FXML
    private ChoiceBox<String> monthChoiceBox;

    @FXML
    private TextField smAmountField;

    @FXML
    private TableColumn<SalaryManagement, String> smMonthColumn;

    @FXML
    private TableColumn<SalaryManagement, String> smNameColumn;

    @FXML
    private TableColumn<SalaryManagement, Number> smSalaryColumn;

    @FXML
    private TableView<SalaryManagement> smTableView;

    private static SalaryManagement oldSalary;

    private static ObservableList<SalaryManagement> salaryObservableList = FXCollections.observableArrayList();


    @FXML
    void saveEvent(ActionEvent event) {
        String employeeName = employeeNameChoiceBox.getValue();
        String month = monthChoiceBox.getValue();
        double salary = Double.parseDouble(smAmountField.getText());

        SalaryManagement salaryManagement = new SalaryManagement(employeeName, month, salary);
        SalaryManagementService salaryManagementService = new SalaryManagementService();
        salaryManagementService.insert(salaryManagement);
        defaultTableView();

    }

    @FXML
    void selectedRow(MouseEvent event) {
        SalaryManagement salaryManagement = smTableView.getSelectionModel().getSelectedItem();
        if (salaryManagement == null) {
            System.out.println("No row selected");
            return;
        }
        showData(salaryManagement);
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String search = searchField.getText();
        SalaryManagementService salaryManagementService = new SalaryManagementService();
        salaryObservableList.setAll(salaryManagementService.getSearchList(search.trim().toLowerCase()));
    }

    @FXML
    void updateEvent(ActionEvent event) {
        SalaryManagement salaryManagement = new SalaryManagement(oldSalary.getEmployeeName(), monthChoiceBox.getValue().toString(), Double.parseDouble(smAmountField.getText()));
        SalaryManagementService salaryManagementService = new SalaryManagementService();
        salaryManagementService.update(oldSalary, salaryManagement);

        defaultTableView();
        System.out.println("Update button clicked");
    }

    @FXML
    void deleteEvent(ActionEvent event) {
        SalaryManagementService salaryManagementService = new SalaryManagementService();
        salaryManagementService.delete(oldSalary);
        defaultTableView();
    }

    @FXML
    void clearEvent(ActionEvent event) {
        employeeNameChoiceBox.setValue(null);
        monthChoiceBox.setValue(null);
        smAmountField.clear();

        smTableView.getSelectionModel().clearSelection();
        oldSalary = null;
    }

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }
    

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        tableMapping();
        defaultTableView();

        List<String> employeeEmails = SalaryManagementService.getAllEmployeeEmails();
        employeeNameChoiceBox.getItems().addAll(employeeEmails);

        ObservableList<String> statusList = FXCollections.observableArrayList();
        statusList.add("January");
        statusList.add("February");
        statusList.add("March");
        statusList.add("April");
        statusList.add("May");
        statusList.add("June");
        statusList.add("July");
        statusList.add("August");
        statusList.add("September");
        statusList.add("October");
        statusList.add("November");
        statusList.add("December");
        monthChoiceBox.setItems(statusList);
    }

    private void tableMapping(){
        smNameColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getEmployeeName()));
        smMonthColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getMonth()));
        smSalaryColumn.setCellValueFactory(c-> new SimpleDoubleProperty(c.getValue().getSalary()));
        smTableView.setItems(salaryObservableList);
    }

    public void defaultTableView(){
        SalaryManagementService salaryManagementService = new SalaryManagementService();
        salaryObservableList.setAll(salaryManagementService.getList());
    }

    private void showData(SalaryManagement salary){
        oldSalary = salary;
        employeeNameChoiceBox.setValue(salary.getEmployeeName());
        monthChoiceBox.setValue(salary.getMonth());
        smAmountField.setText(Double.toString(salary.getSalary()));
    }
}

