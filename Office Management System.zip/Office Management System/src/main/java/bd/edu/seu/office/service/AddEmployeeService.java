package bd.edu.seu.office.service;

import bd.edu.seu.office.interfaces.AddEmployeeInterface;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.util.ConnectionSingleton;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AddEmployeeService implements AddEmployeeInterface {

    @Override
    public void insert(AddEmp table) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "insert into add_employee values(?,?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, table.getName());
            preparedStatement.setString(2, table.getEmail());
            preparedStatement.setString(3, table.getPhone());
            preparedStatement.setString(4, table.getPassword());
            preparedStatement.setString(5, table.getDate().toString());
            preparedStatement.setString(6, table.getGender());
            preparedStatement.executeUpdate();

        }  catch (SQLIntegrityConstraintViolationException e) {
            // Duplicate entry error
            System.out.println("Duplicate email! This email already exists.");
        }
        catch (SQLException ex) {
            System.out.println("Failed to insert data into database");
            ex.printStackTrace();
        }
    }

    @Override
    public void update(AddEmp old, AddEmp update) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "update add_employee set name=?, email=?, phone=?, date=?, password=?, gender=? where email=? and phone=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, update.getName());
            preparedStatement.setString(2, update.getEmail());
            preparedStatement.setString(3, update.getPhone());
            preparedStatement.setString(4, update.getDate().toString());
            preparedStatement.setString(5, update.getPassword());
            preparedStatement.setString(6, update.getGender());
            preparedStatement.setString(7, old.getEmail());
            preparedStatement.setString(8, old.getPhone());
            preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Failed to update data into database");
            ex.printStackTrace();
        }

        }

    @Override
    public void delete(AddEmp old) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "delete from add_employee where email=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, old.getEmail());
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Failed to delete data into database");
            ex.printStackTrace();
        }
    }

    @Override
    public List<AddEmp> getList() {
        List<AddEmp> list = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "select * from add_employee";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                AddEmp emp = new AddEmp(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6));
                list.add(emp);
            }
        }catch (SQLException ex) {
            System.out.println("Failed to get data from database");
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<AddEmp> getSearchList(String search) {
        return getList().stream().filter(emp -> emp.getEmail().toLowerCase().contains(search)
        || emp.getPhone().toLowerCase().contains(search)).toList();
    }

    public AddEmp loginCheck(String email, String password) {
        AddEmp user = null;

        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT * FROM add_employee WHERE email = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new AddEmp(
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("phone"),
                        resultSet.getString("password"),
                        resultSet.getString("date"),
                        resultSet.getString("gender")
                );
            }

        } catch (SQLException ex) {
            System.out.println("Don't find any employee with this email");
            ex.printStackTrace();

        }

        return user; // if null then login fail
    }

    public AddEmp getByEmail(String email) {
        AddEmp emp = null;
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT * FROM add_employee WHERE email = ?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                emp = new AddEmp(
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("password"),
                        rs.getString("date"),
                        rs.getString("gender")
                );
                System.out.println("Successfully found employee with this email");
            } else {
                System.out.println("No employee found with this email");
            }
        } catch (SQLException e) {
            System.out.println("getByEmail failed to connect to the database");
            e.printStackTrace();
        }
        return emp;
    }
           public List<String> getAllEmployeeEmails() {
           List<String> emails = new ArrayList<>();
              try {
            Connection conn = ConnectionSingleton.getConnection();
            String query = "SELECT email FROM add_employee";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                emails.add(rs.getString("email"));
            }

        } catch (SQLException e) {
            System.out.println("Failed to connect getAllEmployeeEmails from database");
            e.printStackTrace();
        }

        return emails;
    }

//    for forget password
    public void updatePasswordByEmail(String email, String newPassword) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "UPDATE add_employee SET password = ? WHERE email = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, email);
            int rows = preparedStatement.executeUpdate();

            if (rows == 0) {
                System.out.println("No user found with this email.");
            }
        } catch (SQLException ex) {
            System.out.println("Failed to updatePasswordByEmail into database");
            ex.printStackTrace();
        }
    }

    public boolean isEmailExists(String email) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT email FROM add_employee WHERE email = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, email);
            ResultSet resultSet = preparedStatement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            System.out.println("Failed to check isEmailExists in database");
            e.printStackTrace();
            return false;
        }
    }
}

