package bd.edu.seu.office.service;

import bd.edu.seu.office.interfaces.SalaryManagementInterface;
import bd.edu.seu.office.model.AttendanceManagement;
import bd.edu.seu.office.model.SalaryManagement;
import bd.edu.seu.office.util.ConnectionSingleton;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static bd.edu.seu.office.util.ConnectionSingleton.getConnection;

public class SalaryManagementService implements SalaryManagementInterface {


    @Override
    public void insert(SalaryManagement table) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "insert into salary_management values(?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, table.getEmployeeName());
            preparedStatement.setString(2, table.getMonth());
            preparedStatement.setDouble(3, table.getSalary());
            preparedStatement.executeUpdate();
        } catch (SQLException ex){
            System.out.println("Failed to insert into salary_management table");
            ex.printStackTrace();
        }
    }

    @Override
    public void update(SalaryManagement old, SalaryManagement update) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "update salary_management set month=?, salary=? where name=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, update.getMonth());
            preparedStatement.setDouble(2, update.getSalary());
            preparedStatement.setString(3, old.getEmployeeName());
            preparedStatement.executeUpdate();

        } catch (SQLException ex){
            System.out.println("Failed to update salary_management table");
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(SalaryManagement old) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "delete from salary_management where name=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, old.getEmployeeName());
            preparedStatement.executeUpdate();

        } catch (SQLException ex){
            System.out.println("Failed to delete salary_management table");
            ex.printStackTrace();
        }
    }

    @Override
    public List<SalaryManagement> getList() {
        List<SalaryManagement> list = new ArrayList<>();
        try {
            Connection connection = getConnection();
            String query = "select * from salary_management";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                SalaryManagement sm = new SalaryManagement(resultSet.getString(1), resultSet.getString(2), resultSet.getDouble(3));
                list.add(sm);
            }
        } catch (SQLException ex) {
            System.out.println("Failed to get salary management data from database");
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<SalaryManagement> getSearchList(String search) {
        return getList().stream().filter(sm -> sm.getEmployeeName().toLowerCase().contains(search)
                || sm.getMonth().toLowerCase().contains(search)).toList();
    }

    public static List<String> getAllEmployeeEmails() {
        List<String> emailList = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT email FROM add_employee";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                emailList.add(resultSet.getString("email"));
            }
        } catch (SQLException ex) {
            System.out.println("Failed to get all employee emails from database");
            ex.printStackTrace();
        }

        return emailList;
    }
}
