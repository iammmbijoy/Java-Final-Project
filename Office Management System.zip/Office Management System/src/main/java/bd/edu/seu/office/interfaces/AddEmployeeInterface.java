package bd.edu.seu.office.interfaces;

import bd.edu.seu.office.model.AddEmp;

import java.util.List;

public interface AddEmployeeInterface {
    void insert(AddEmp table);
    void update(AddEmp old, AddEmp update);
    void delete(AddEmp old);
    List<AddEmp> getList();
    List<AddEmp> getSearchList(String search);

}
