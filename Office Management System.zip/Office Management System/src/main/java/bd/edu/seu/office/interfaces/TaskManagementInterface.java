package bd.edu.seu.office.interfaces;

import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.model.TaskManagement;

import java.util.List;

public interface TaskManagementInterface {
    void insert(TaskManagement table);
    void update(TaskManagement old, TaskManagement update);
    void delete(TaskManagement old);
    List<TaskManagement> getList();
    List<TaskManagement> getSearchList(String search);
}
