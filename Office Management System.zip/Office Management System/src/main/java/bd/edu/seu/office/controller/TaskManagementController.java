package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.model.TaskManagement;
import bd.edu.seu.office.service.AddEmployeeService;
import bd.edu.seu.office.service.TaskManagementService;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class TaskManagementController implements Initializable {

    @FXML
    private TableColumn<TaskManagement, String> tmDeadlineColumn;

    @FXML
    private DatePicker tmDeadlineField;

    @FXML
    private TableColumn<TaskManagement, String> tmDescriptionColumn;

    @FXML
    private TextField tmDescriptionField;

    @FXML
    private TableColumn<TaskManagement, String> tmNameColumn;

    @FXML
    private TextField tmNameField;

    @FXML
    private TableColumn<TaskManagement, Number> tmNumberColumn;

    @FXML
    private TextField tmNumberField;

    @FXML
    private TextField tmSearchField;

    @FXML
    private TableView<TaskManagement> tmTableView;

    private static TaskManagement oldTask;

    private static ObservableList<TaskManagement> taskObservableList = FXCollections.observableArrayList();

    @FXML
    void saveEvent(ActionEvent event) {
        int number = Integer.parseInt(tmNumberField.getText());
        String name = tmNameField.getText();
        String deadline = tmDeadlineField.getValue().toString();
        String description = tmDescriptionField.getText();


        TaskManagement taskManagement = new TaskManagement(number, name, deadline, description);
        TaskManagementService taskManagementService = new TaskManagementService();
        taskManagementService.insert(taskManagement);
        defaultTableView();
    }

    @FXML
    void selectedRow(MouseEvent event) {
        TaskManagement taskManagement= tmTableView.getSelectionModel().getSelectedItem();
        if (taskManagement == null) {
            System.out.println("No row selected");
            return;
        }

        showData(taskManagement);
    }

    @FXML
    void clearEvent(ActionEvent event) {
        tmNumberField.clear();
        tmNameField.clear();
        tmDeadlineField.setValue(null);
        tmDescriptionField.clear();


        tmTableView.getSelectionModel().clearSelection(); // Unselect row
        oldTask = null;
    }

    @FXML
    void deleteEvent(ActionEvent event) {
        TaskManagementService taskManagementService = new TaskManagementService();
        taskManagementService.delete(oldTask);
        defaultTableView();
    }

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String search = tmSearchField.getText();
        TaskManagementService taskManagementService = new TaskManagementService();
        taskObservableList.setAll(taskManagementService.getSearchList(search.trim().toLowerCase()));
    }

    @FXML
    void updateEvent(ActionEvent event) {
        TaskManagement updateTask = new TaskManagement(oldTask.getNumber(), tmNameField.getText(), tmDeadlineField.getValue().toString(), tmDescriptionField.getText());
        TaskManagementService taskManagementService = new TaskManagementService();
        taskManagementService.update(oldTask, updateTask);
        defaultTableView();
        System.out.println("Update button clicked");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableMapping();
        defaultTableView();
    }

    private void tableMapping(){
        tmNumberColumn.setCellValueFactory(c-> new SimpleIntegerProperty(c.getValue().getNumber()));
        tmNameColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getName()));
        tmDeadlineColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getDeadline()));
        tmDescriptionColumn.setCellValueFactory(c-> new SimpleStringProperty(c.getValue().getDescription()));
        tmTableView.setItems(taskObservableList);
    }

    public void defaultTableView(){
        TaskManagementService taskManagementService = new TaskManagementService();
        taskObservableList.setAll(taskManagementService.getList());
    }

    private void showData(TaskManagement task){
        oldTask = task;
        tmNumberField.setText(String.valueOf(task.getNumber()));
        tmNameField.setText(task.getName());
        tmDeadlineField.setValue(LocalDate.parse(task.getDeadline()));
        tmDescriptionField.setText(task.getDescription());
    }
}
