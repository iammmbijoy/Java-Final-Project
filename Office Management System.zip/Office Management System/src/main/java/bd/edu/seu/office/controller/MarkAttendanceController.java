package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AttendanceManagement;
import bd.edu.seu.office.service.AttendanceManagementService;
import bd.edu.seu.office.util.Session;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class MarkAttendanceController {

    @FXML
    private DatePicker attendanceDateField;

    @FXML
    private TableView<AttendanceManagement> attendanceView;

    @FXML
    private TableColumn<AttendanceManagement, String> dateColumn;

    @FXML
    private ChoiceBox<String> markAttendanceField;

    @FXML
    private TextField searchField;

    @FXML
    private TableColumn<AttendanceManagement, String> statusColumn;

    private AttendanceManagement selectedAttendance;
    private ObservableList<AttendanceManagement> userAttendanceList = FXCollections.observableArrayList();

    @FXML
    void initialize() {

        new AttendanceManagementService().markAbsentForAllIfNotExists(); // for mark auto attendance daily


        LocalTime now = LocalTime.now();
        ObservableList<String> statusOptions;
        if (now.isAfter(LocalTime.of(10, 0))) {
            statusOptions = FXCollections.observableArrayList("Absent", "Sick");
        } else {
            statusOptions = FXCollections.observableArrayList("Present", "Absent", "Sick");
        }
        markAttendanceField.setItems(statusOptions);

        tableMapping();
        loadCurrentUserAttendance();
    }


    private void tableMapping() {
        dateColumn.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDate()));
        statusColumn.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getAttendance()));
        attendanceView.setItems(userAttendanceList);
    }

    private void loadCurrentUserAttendance() {
        AttendanceManagementService service = new AttendanceManagementService();
        String email = Session.getCurrentUserEmail();

        List<AttendanceManagement> list = service.getList().stream()
                .filter(am -> am.getName().equals(email))
                .toList();
        userAttendanceList.setAll(list);
    }

    @FXML
    void attendanceTable(MouseEvent event) {
        selectedAttendance = attendanceView.getSelectionModel().getSelectedItem();
        if (selectedAttendance == null) return;

        attendanceDateField.setValue(LocalDate.parse(selectedAttendance.getDate()));
        markAttendanceField.setValue(selectedAttendance.getAttendance());

        // Disable "Present" if current time > 10:00 AM
        LocalTime now = LocalTime.now();
        if (now.isAfter(LocalTime.of(10, 0))) {
            markAttendanceField.setItems(FXCollections.observableArrayList("Absent", "Sick"));
        } else {
            markAttendanceField.setItems(FXCollections.observableArrayList("Present", "Absent", "Sick"));
        }
    }

    @FXML
    void updateEvent(ActionEvent event) {
        if (selectedAttendance == null) {
            showAlert(Alert.AlertType.ERROR, "Please select a row to update.");
            return;
        }

        String newStatus = markAttendanceField.getValue();
        if (newStatus == null) {
            showAlert(Alert.AlertType.ERROR, "Please select a status.");
            return;
        }

        AttendanceManagement updated = new AttendanceManagement(
                selectedAttendance.getName(),
                selectedAttendance.getDate(),
                newStatus
        );

        AttendanceManagementService service = new AttendanceManagementService();
        service.update(selectedAttendance, updated);

        loadCurrentUserAttendance();
        showAlert(Alert.AlertType.INFORMATION, "Attendance updated successfully.");
    }

    @FXML
    void searchEvent(KeyEvent event) {
        String searchText = searchField.getText().toLowerCase();
        AttendanceManagementService service = new AttendanceManagementService();
        String email = Session.getCurrentUserEmail();

        List<AttendanceManagement> searchResults = service.getList().stream()
                .filter(am -> am.getName().equals(email) &&
                        (am.getDate().toLowerCase().contains(searchText) ||
                                am.getAttendance().toLowerCase().contains(searchText)))
                .toList();
        userAttendanceList.setAll(searchResults);
    }

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

