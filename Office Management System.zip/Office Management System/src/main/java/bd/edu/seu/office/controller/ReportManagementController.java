package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AttendanceManagement;
import bd.edu.seu.office.model.MyTask;
import bd.edu.seu.office.model.SalaryManagement;
import bd.edu.seu.office.service.AssignTaskService;
import bd.edu.seu.office.service.AttendanceManagementService;
import bd.edu.seu.office.service.SalaryManagementService;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ReportManagementController {

    @FXML
    private PieChart attendanceChart;

    @FXML
    private LineChart<String, Number> salaryChart;

    @FXML
    private PieChart taskChart;

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    public void initialize() {
        loadAttendanceChart();
        loadTaskChart();
        loadSalaryChart();
    }

    private void loadAttendanceChart() {
        AttendanceManagementService service = new AttendanceManagementService();
        List<AttendanceManagement> allAttendance = service.getList();

        long present = allAttendance.stream().filter(a -> a.getAttendance().equalsIgnoreCase("Present")).count();
        long absent = allAttendance.stream().filter(a -> a.getAttendance().equalsIgnoreCase("Absent")).count();
        long sick = allAttendance.stream().filter(a -> a.getAttendance().equalsIgnoreCase("Sick")).count();

        long total = present + absent + sick;

        attendanceChart.setData(FXCollections.observableArrayList(
                new PieChart.Data(String.format("Present %.1f%%", present * 100.0 / total), present),
                new PieChart.Data(String.format("Absent %.1f%%", absent * 100.0 / total), absent),
                new PieChart.Data(String.format("Sick %.1f%%", sick * 100.0 / total), sick)
        ));
        attendanceChart.setTitle("Attendance Summary");
    }


    private void loadTaskChart() {
        AssignTaskService service = new AssignTaskService();
        List<MyTask> allTasks = service.getAllTasks();

        long completed = allTasks.stream().filter(t -> t.getStatus().equalsIgnoreCase("Completed")).count();
        long inProgress = allTasks.stream().filter(t -> t.getStatus().equalsIgnoreCase("In Progress")).count();
        long pending = allTasks.stream().filter(t -> t.getStatus().equalsIgnoreCase("Pending")).count();

        long total = completed + inProgress + pending;

        taskChart.setData(FXCollections.observableArrayList(
                new PieChart.Data(String.format("Completed %.1f%%", completed * 100.0 / total), completed),
                new PieChart.Data(String.format("In Progress %.1f%%", inProgress * 100.0 / total), inProgress),
                new PieChart.Data(String.format("Pending %.1f%%", pending * 100.0 / total), pending)
        ));
        taskChart.setTitle("Task Status Summary");
    }

    private void loadSalaryChart() {
        SalaryManagementService service = new SalaryManagementService();
        List<SalaryManagement> allSalaries = service.getList();

        Map<String, Double> salaryByMonth = new LinkedHashMap<>();
        List<String> months = List.of("January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December");

        for (String month : months) {
            salaryByMonth.put(month, 0.0);
        }

        for (SalaryManagement s : allSalaries) {
            String month = s.getMonth();
            if (salaryByMonth.containsKey(month)) {
                salaryByMonth.put(month, salaryByMonth.get(month) + s.getSalary());
            }
        }

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Salary per Month");

        for (String month : months) {
            series.getData().add(new XYChart.Data<>(month, salaryByMonth.get(month)));
        }

        salaryChart.getData().clear();
        salaryChart.getData().add(series);
    }
}

