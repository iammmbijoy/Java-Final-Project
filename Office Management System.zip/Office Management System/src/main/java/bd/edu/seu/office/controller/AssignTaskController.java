package bd.edu.seu.office.controller;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.service.AddEmployeeService;
import bd.edu.seu.office.service.AssignTaskService;
import bd.edu.seu.office.service.TaskManagementService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.ResourceBundle;

public class AssignTaskController implements Initializable {

    @FXML
    private TableColumn<AssignTask, String> atDeadlineColumn;

    @FXML
    private DatePicker atDeadlinePicker;

    @FXML
    private ChoiceBox<String> atEmployeeChoiceBox;

    @FXML
    private TableColumn<AssignTask, String> atEmployeeNameColumn;

    @FXML
    private TextField atSearchField;

    @FXML
    private TableColumn<AssignTask, String> atStatusColumn;

    @FXML
    private ChoiceBox<String> atTaskStatusChoiceBox;

    @FXML
    private TableView<AssignTask> atTableView;

    @FXML
    private ChoiceBox<String> atTaskChoiceBox;

    @FXML
    private TableColumn<AssignTask, String> atTaskColumn;

    private static AssignTask oldTask;

    private static ObservableList<AssignTask> assignTaskObservableList = FXCollections.observableArrayList();

    @FXML
    void selectedRow(MouseEvent event) {
        AssignTask selected = atTableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            System.out.println("No row selected");
            return;
        }
        showData(selected);
    }

    @FXML
    void clearEvent(ActionEvent event) {
        atEmployeeChoiceBox.setValue(null);
        atTaskChoiceBox.setValue(null);
        atDeadlinePicker.setValue(null);
        atTaskStatusChoiceBox.setValue(null);


        atTableView.getSelectionModel().clearSelection(); // Unselect row
        oldTask = null;
    }

    @FXML
    void deleteEvent(ActionEvent event) {
        AssignTaskService assignTaskService = new AssignTaskService();
        assignTaskService.delete(oldTask);
        defaultTableView();
    }

    @FXML
    void exitEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    void saveEvent(ActionEvent event) {
        String name = atEmployeeChoiceBox.getValue();
        String task = atTaskChoiceBox.getValue();
        String deadline = atDeadlinePicker.getValue().toString();
        String status = atTaskStatusChoiceBox.getValue();

        AssignTask assignTask = new AssignTask(name, task, deadline, status);
        AssignTaskService assignTaskService = new AssignTaskService();
        assignTaskService.insert(assignTask);
        defaultTableView();

    }

    @FXML
    void searchEvent(KeyEvent event) {
        String search = atSearchField.getText();
        AssignTaskService assignTaskService = new AssignTaskService();
        assignTaskObservableList.setAll(assignTaskService.getSearchList(search.trim().toLowerCase()));
    }

    @FXML
    void updateEvent(ActionEvent event) {
         AssignTask updateTask = new AssignTask(atEmployeeChoiceBox.getValue(), atTaskChoiceBox.getValue(), atDeadlinePicker.getValue().toString(), atTaskStatusChoiceBox.getValue());
         AssignTaskService assignTaskService = new AssignTaskService();
         assignTaskService.update(oldTask, updateTask);
        defaultTableView();
        System.out.println("Update button clicked");
    }


    private void loadTaskNames() {
        TaskManagementService taskService = new TaskManagementService();
        List<String> taskNames = taskService.getAllTaskNames();
        atTaskChoiceBox.setItems(FXCollections.observableArrayList(taskNames));
    }

    private void loadEmployeeEmails() {
        AddEmployeeService employeeService = new AddEmployeeService();
        List<String> employeeEmails = employeeService.getAllEmployeeEmails(); // Now using email
        atEmployeeChoiceBox.setItems(FXCollections.observableArrayList(employeeEmails));
    }


    private void tableMapping(){
        atEmployeeNameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        atTaskColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTask()));
        atDeadlineColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getDeadline()));
        atStatusColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getStatus()));
        atTableView.setItems(assignTaskObservableList);
    }

    public void defaultTableView(){
        AssignTaskService assignTaskService = new AssignTaskService();
        assignTaskObservableList.setAll(assignTaskService.getList());


    }

    private void showData(AssignTask assignTask){
        oldTask = assignTask;

        atEmployeeChoiceBox.setValue(assignTask.getName());
        atTaskChoiceBox.setValue(assignTask.getTask());
        atDeadlinePicker.setValue(LocalDate.parse(assignTask.getDeadline()));
        atTaskStatusChoiceBox.setValue(assignTask.getStatus());
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadTaskNames();
        loadEmployeeEmails();
        tableMapping();
        defaultTableView();


        ObservableList<String> statusList = FXCollections.observableArrayList();
        statusList.add("Completed");
        statusList.add("In Progress");
        statusList.add("Pending");
        atTaskStatusChoiceBox.setItems(statusList);
    }
}
