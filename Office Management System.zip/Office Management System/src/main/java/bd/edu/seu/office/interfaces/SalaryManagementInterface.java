package bd.edu.seu.office.interfaces;
import bd.edu.seu.office.model.SalaryManagement;
import java.util.List;

public interface SalaryManagementInterface {
    void insert(SalaryManagement table);
    void update(SalaryManagement old, SalaryManagement update);
    void delete(SalaryManagement old);
    List<SalaryManagement> getList();
    List<SalaryManagement> getSearchList(String search);
}
