package bd.edu.seu.office.service;

import bd.edu.seu.office.interfaces.TaskManagementInterface;
import bd.edu.seu.office.model.AddEmp;
import bd.edu.seu.office.model.TaskManagement;
import bd.edu.seu.office.util.ConnectionSingleton;
import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaskManagementService implements TaskManagementInterface {
    @Override
    public void insert(TaskManagement table) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "insert into task_management values(?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, table.getNumber());
            preparedStatement.setString(2, table.getName());
            preparedStatement.setString(3, table.getDeadline());
            preparedStatement.setString(4, table.getDescription());
            preparedStatement.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException e) {
            // Duplicate entry error
            System.out.println("Duplicate Number! This number already exists.");
        }
        catch (SQLException ex) {
            System.out.println("Failed to insert data into task_management table");
            ex.printStackTrace();
        }


    }

    @Override
    public void update(TaskManagement old, TaskManagement update) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "update task_management set number = ?, name = ?, deadline = ?, description = ? where number = ? and name = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, update.getNumber());
            preparedStatement.setString(2, update.getName());
            preparedStatement.setString(3, update.getDeadline());
            preparedStatement.setString(4, update.getDescription());
            preparedStatement.setInt(5, old.getNumber());
            preparedStatement.setString(6, old.getName());
            preparedStatement.executeUpdate();

        } catch (SQLException ex){
            System.out.println("Failed to update data into task_management table");
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(TaskManagement old) {
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "delete from task_management where number = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, old.getNumber());
            preparedStatement.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Failed to delete data into task_management table");
            ex.printStackTrace();
        }
    }


    @Override
    public List<TaskManagement> getList() {
        List<TaskManagement> list = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "select * from task_management";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                TaskManagement tm = new TaskManagement(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
                list.add(tm);
            }
        }catch (SQLException ex) {
            System.out.println("Failed to getList from database");
            ex.printStackTrace();
        }
        return list;
    }

    @Override
    public List<TaskManagement> getSearchList(String search) {
        return getList().stream().filter(tm -> tm.getName().toLowerCase().contains(search)).toList();
    }


    public List<String> getAllTaskNames() {
        List<String> taskNames = new ArrayList<>();
        try {
            Connection connection = ConnectionSingleton.getConnection();
            String query = "SELECT name FROM task_management";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                taskNames.add(resultSet.getString("name"));
            }
        } catch (SQLException ex) {
            System.out.println("Failed to getAllTaskNames");
            ex.printStackTrace();
        }
        return taskNames;
    }


}
