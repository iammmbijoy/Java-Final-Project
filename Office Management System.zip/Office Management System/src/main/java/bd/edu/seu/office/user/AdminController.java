package bd.edu.seu.office.user;

import bd.edu.seu.office.HelloApplication;
import bd.edu.seu.office.model.AssignTask;
import bd.edu.seu.office.service.AssignTaskService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AdminController implements Initializable {

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField visiblePasswordField;

    @FXML
    private CheckBox showPasswordCheckBox;

    @FXML
    void loginEvent(ActionEvent event) {

        String username = usernameField.getText();
        String password = passwordField.getText();


        if (username.equals("admin") && password.equals("1234")) {
            HelloApplication.changeScene("admin_dashboard");
        } else {
            if (username.isEmpty() || password.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error!");
                alert.setHeaderText(null);
                alert.setContentText("Please enter your username or password!");
                alert.showAndWait();
            } else {
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText("Wrong Username or Password");
                errorAlert.showAndWait();
                System.err.println("Wrong username or Password.");
            }
        }
    }

    @FXML
    void backEvent(ActionEvent event) {
        HelloApplication.changeScene("login");
    }

    @FXML
    void togglePasswordVisibility(ActionEvent event) {
        if (showPasswordCheckBox.isSelected()) {
            visiblePasswordField.setText(passwordField.getText());
            visiblePasswordField.setVisible(true);
            visiblePasswordField.setManaged(true);
            passwordField.setVisible(false);
            passwordField.setManaged(false);
        } else {
            passwordField.setText(visiblePasswordField.getText());
            passwordField.setVisible(true);
            passwordField.setManaged(true);
            visiblePasswordField.setVisible(false);
            visiblePasswordField.setManaged(false);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        visiblePasswordField.textProperty().bindBidirectional(passwordField.textProperty());
    }
}
