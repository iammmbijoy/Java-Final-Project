module bd.edu.seu.office {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens bd.edu.seu.office to javafx.fxml;
    exports bd.edu.seu.office;

    opens bd.edu.seu.office.controller to javafx.fxml;
    exports bd.edu.seu.office.controller;
    exports bd.edu.seu.office.user;
    opens bd.edu.seu.office.user to javafx.fxml;
    exports bd.edu.seu.office.dashboard;
    opens bd.edu.seu.office.dashboard to javafx.fxml;
}